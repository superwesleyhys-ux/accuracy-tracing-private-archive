# 原版与原版 + Accuracy：直接 A/B 工具

已完成模型接入和真实 API 对照。**18 项接入测试通过；修复后的两组四个实验单元全部完成。**

实测结果见 `LIVE_AB_REPORT.md`：按此前两条合成样例的标签，原版 1/2，加入 Accuracy 后 0/2。样例标注有歧义，不能据此推断真实新闻优劣。早期认证预检及接口失败仍保留在 reports 中，属于历史记录。

## 两个实验组

| 实验组 | 执行步骤 |
|---|---|
| original | 原项目 `NewsTracingAgent.run` 在固定材料库上运行，然后生成统一格式的最终判断 |
| accuracy | 同样运行原项目，再让 Accuracy 重新分解、追踪和验证这些材料，最后生成同一格式的判断 |

这次增加的是 Accuracy 复核阶段。两组都调用同一个明确指定的模型，使用相同的源材料、时间过滤、原流程因果深度和每题资源上限。下面的通用 `run` 命令让两组分别运行。本次修复后的实测使用 `paired_augmentation.py`，明确复用每题的同一份原版分析，并将复用资源计入 Accuracy 的预算；完整方法和局限见实测报告。

两组共用最终判断的 schema 和格式化提示。Accuracy 组的最终格式化不得升级回环已经保留为 unresolved 的结论。原报告是待检查的假设，不能当成事实标签。

## 实验控制与限制

- 材料被冻结；原代码中的搜索模型调用被适配为“仅根据提供材料作答”的同模型调用。本实验比较固定材料上的推理与复核，不评测实时网络检索召回。
- 两组首先按同一截止时间排除不可用材料，再调用模型。原代码源文件未修改，但该共享前处理和最终格式化意味着这是受控适配后的原版，不是原网站的原封不动线上体验。
- Accuracy 每次收到材料后都会进入分解器；有缺口时可重新处理相同材料，最多 3 轮。本版本没有声称能找到冻结材料库以外的新来源。
- 新适配器要求平铺片段的 parent_id 等于目标 ID；对被时间规则排除的材料不发起语义模型调用。这些防护属于新增适配器，未写回两个 GitHub 仓库。
- API 调用次数、实际输入/输出 token、响应模型 ID、请求和输出文本均会记录。HTTP/SDK 自动重试关闭；错误不会被悄悄忽略。
- 两组每题上限：24 次模型调用、24,000 个输出 token（包含推理 token）、每次最多 2,000 个输出 token、300 秒。输入 token 记录但没有总量硬上限。它们是相同资源上限，不是相同实际成本。
- 每个题目的两组运行顺序按固定随机种子打乱；本版本每组每题运行一次，不输出统计显著性结论。
- 任一组失败会完整保留错误并使总体准确率报告不可用，不能删除失败题后只报告剩余题。
- 模型内部知识无法由提示词彻底抹除；“只使用给定材料”指令不等于消除了预训练数据污染。

API 的 `max_completion_tokens` 约束输出及推理 token；结构化输出约束 schema，并不保证语义真实。[OpenAI API 参数](https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create) · [结构化输出说明](https://developers.openai.com/api/docs/guides/structured-outputs)

## 文件

| 文件 | 用途 |
|---|---|
| `direct_ab.py` | 模型调用、原版/Accuracy 适配、资源记录、最终格式和独立评分 |
| `examples/inputs.synthetic.json` | 两个虚构新闻案例，只含目标和材料 |
| `examples/gold.synthetic.json` | 对应的单独答案标签，推理命令没有读取此文件的入口 |
| `tests/test_direct_ab.py` | 18 项接入及边界测试，模型响应全部为显式测试替身 |
| `reports/validation-live-adapter.json` | 本次 18 项接入测试结果 |
| `reports/live-attempt-03-shared-prefix/` | 修复后的真实配对结果、调用记录、完整 trace 和七项评分 |
| `paired_augmentation.py` | 对同一份原版分析增加 Accuracy，复用资源仍计入预算 |
| `reports/live-preflight/` | 实际运行尝试的配置、源码指纹和认证阻塞状态 |

输入/答案样例仅用于测试工具接入。即便后来用真实 API 跑这两题，成绩也只能称为两个合成案例的结果，不能泛化为真实新闻准确率。

## 运行

Python 3.11+。先在此目录旁准备两个固定提交的项目源码：

```bash
git clone https://github.com/superwesleyhys-ux/news-tracking-perdiction.git original
git -C original checkout 789506115e7dfef1f2359c2e43bcae4234b8d3f2
git clone https://github.com/superwesleyhys-ux/accuracy-tracing.git accuracy
git -C accuracy checkout aca102cfe13379c5924a5ffa7b60337351e4eaaa
python3 -m venv venv
venv/bin/python -m pip install -r original/requirements.txt
```

将模型 API 认证配置到实际执行环境的 `OPENAI_API_KEY`，无需把密钥放进聊天或代码仓库。模型必须用 `--model` 明确指定；不会自动换成其他模型。本次已验证并实际调用 `gpt-6-astra`；不会自动切换模型。若当前环境使用 SOCKS 代理，还需安装 `socksio`。

```bash
venv/bin/python direct_ab.py run \
  --inputs examples/inputs.synthetic.json \
  --original original --accuracy accuracy \
  --model gpt-6-astra --depth 1 \
  --output runs/first-pair
```

输出目录必须是新目录，防止覆盖已完成运行。命令会逐题写入原报告、Accuracy trace、每次调用及资源记录。

推理结束后，单独读取答案文件评分：

```bash
venv/bin/python direct_ab.py score \
  --gold examples/gold.synthetic.json \
  --run runs/first-pair --accuracy accuracy
```

`scores.json` 会保存两组完整评分、七项主指标的差值、分类混淆矩阵和其他诊断。零分母指标仍为 null。全部样本和证据 ID 必须与审定数据一致；错误不通过删样本处理。

真实新闻实验应使用另行审定的案例、材料快照和来源关系标签，并保持推理输入与答案文件分离。

## 本次验证

18 项接入测试全部通过，失败/错误/跳过均为 0，测试中的模型响应都是替身。真实调用、此前失败和修复后的两题对照另存于 `reports/live-attempt-*`。

本次确认了模型接入和回环运行；没有证明真实新闻准确率提升。`secure_live_session.py` 与 `secure_shared_session.py` 是此次运行的交互式凭据入口，后者固定了这次保存的基线和新目录；通用重跑请使用上面的 CLI，或调用 `paired_augmentation.run(root, baseline, new_output)` 并指定新目录。

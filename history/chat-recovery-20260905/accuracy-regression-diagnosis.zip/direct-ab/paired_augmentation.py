"""Compare a saved original report with Accuracy augmentation of that exact report.

The shared original prefix is charged to BOTH arms' logical budgets, but is not
sent to the API a second time. Inference never opens the gold file.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import shutil
import time

import direct_ab as ab


def seed_prefix(client, records, baseline_usage):
    if len(records) < 2 or "final assessment" not in records[-1]["system"]:
        raise ValueError("Cache must contain an original prefix followed by one final formatter")
    prefix = deepcopy(records[:-1])
    if any("error_type" in r or r.get("actual_model") != client.model for r in prefix):
        raise ValueError("Cache contains an error or a different model")
    if any(r["sequence"] != i + 1 for i, r in enumerate(records)):
        raise ValueError("Cache sequence is incomplete")
    for r in prefix: r["reused_common_prefix"] = True
    client.records = prefix
    client.calls = len(prefix)
    client.used_input = sum(r["usage"]["input_tokens"] for r in prefix)
    client.used_output = sum(r["usage"]["output_tokens"] for r in prefix)
    charged_seconds = max(0.0, baseline_usage["seconds"] - records[-1]["seconds"])
    client.start = time.monotonic() - charged_seconds
    return {"model_calls": client.calls, "input_tokens": client.used_input,
            "output_tokens": client.used_output, "seconds": charged_seconds}


def run(root, baseline, output):
    root, baseline, output = map(Path, (root, baseline, output))
    output.mkdir(parents=True, exist_ok=False)
    source = root.parent / "repo-comparison"
    _, p = ab.load_projects(source / "original", source / "accuracy")
    inputs = ab.clean_inputs(json.loads((root / "examples/inputs.synthetic.json").read_text()))
    old_config = json.loads((baseline / "config.json").read_text())
    if ab.digest(inputs) != old_config["input_digest"]:
        raise ValueError("Inputs changed since baseline inference")
    for name, package in [("original", "agent"), ("accuracy", "newsverify")]:
        folder = source / name / package
        current = {str(f.relative_to(folder)): hashlib.sha256(f.read_bytes()).hexdigest()
                   for f in sorted(folder.rglob("*.py"))}
        if current != old_config["source_fingerprints"][name]:
            raise ValueError("Pinned project implementation changed since baseline")
    originals = [r for r in json.loads((baseline / "results.json").read_text()) if r["arm"] == "original"]
    if len(originals) != len(inputs["cases"]) or any(r["status"] != "completed" for r in originals):
        raise ValueError("All original cases must be completed; no selective cache reuse")
    if {r["id"] for r in originals} != {c["target"]["id"] for c in inputs["cases"]}:
        raise ValueError("Cache case set differs")
    rows = deepcopy(originals)
    for row in rows:
        row["reused_completed_baseline"] = True
        row["actual_new_api_usage"] = {"model_calls": 0, "input_tokens": 0, "output_tokens": 0}
    config = {**old_config, "adapter_sha256": hashlib.sha256(Path(ab.__file__).read_bytes()).hexdigest(),
              "driver_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "variant_definition": "original versus Accuracy added to the exact same cached original report",
              "method": "shared-prefix paired augmentation after interface repair",
              "baseline_directory": str(baseline), "budget": asdict(ab.Budget()),
              "cached_prefix_charged_to_candidate_budget": True,
              "new_calls_only_after_original_prefix": True,
              "time_accounting": "original wall time minus original final-call duration, plus new augmentation wall time",
              "prefix_has_no_original_final_prediction": True,
              "gold_access_during_inference": False, "parallel_cases": 2}
    ab.write(output / "config.json", config)
    ab.write(output / "results.json", rows)

    def one(index, raw_case):
        case, excluded = ab.eligible_case(p, raw_case)
        cached_input = json.loads((baseline / f"case-{index}-shared-input.json").read_text())
        if {"case": case, "excluded": excluded} != cached_input: raise ValueError("Shared input mismatch")
        ab.write(output / f"case-{index}-shared-input.json", cached_input)
        for suffix in ["calls", "report"]:
            shutil.copyfile(baseline / f"case-{index}-original-{suffix}.json", output / f"case-{index}-original-{suffix}.json")
        cache = json.loads((baseline / f"case-{index}-original-calls.json").read_text())
        report = json.loads((baseline / f"case-{index}-original-report.json").read_text())["original_report"]
        baseline_row = next(r for r in originals if r["id"] == case["target"]["id"])

        class RecordedClient(ab.BudgetClient):
            def call(self, *args, **kwargs):
                try: return super().call(*args, **kwargs)
                finally:
                    ab.write(output / f"case-{index}-accuracy-calls.json", self.records)
                    print(json.dumps({"id": case["target"]["id"], "stage": "accuracy_call_finished",
                                      "logical_calls": self.calls, "new_calls": self.calls - len(cache) + 1}), flush=True)

        client = RecordedClient(old_config["model"], ab.Budget(), reasoning_effort=old_config["reasoning_effort"])
        reused = seed_prefix(client, cache, baseline_row["usage"])
        row = {"id": case["target"]["id"], "arm": "accuracy", "status": "error", "prediction": None,
               "reused_prefix_usage": reused}
        try:
            trace = ab.run_accuracy(p, client, case, report)
            # Save the trace BEFORE deciding whether it is valid, including all failures.
            ab.write(output / f"case-{index}-accuracy-report.json", {"original_report": report, "accuracy_trace": trace})
            if trace["errors"]: raise ValueError("Accuracy adapter reported an error")
            row["prediction"] = ab.final_prediction(client, case, report, trace)
            row["status"] = "completed"
        except Exception as exc:
            row["error_type"] = type(exc).__name__
        finally:
            row["usage"] = client.usage()
            row["actual_new_api_usage"] = {k: row["usage"][k] - reused[k] for k in reused}
            ab.write(output / f"case-{index}-accuracy-calls.json", client.records)
            ab.write(output / f"case-{index}-accuracy-result.json", row)
        return row

    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(one, i, case) for i, case in enumerate(inputs["cases"])]
        for future in as_completed(futures):
            row = future.result()
            rows.append(row)
            ab.write(output / "results.json", rows)
            print(json.dumps({"id": row["id"], "arm": row["arm"], "status": row["status"]}), flush=True)
    ab.write(output / "status.json", {"status": "completed" if all(r["status"] == "completed" for r in rows) else "has_errors",
        "actual_new_api_calls": sum(r["actual_new_api_usage"]["model_calls"] for r in rows),
        "logical_arm_calls": sum(r["usage"]["model_calls"] for r in rows)})
    return 0 if all(r["status"] == "completed" for r in rows) else 1

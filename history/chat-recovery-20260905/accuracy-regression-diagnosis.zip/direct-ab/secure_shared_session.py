"""Memory-only API credential handoff for the shared-prefix comparison."""
import argparse
import getpass
import json
import logging
import os
from pathlib import Path
import sys

import direct_ab
import paired_augmentation


def main():
    if not sys.stdin.isatty(): raise SystemExit("An echo-disabled terminal is required")
    logging.disable(logging.CRITICAL)
    root = Path(__file__).resolve().parent
    output = root / "reports/live-attempt-03-shared-prefix"
    if output.exists(): raise SystemExit("Output already exists; do not overwrite a prior trial")
    secret = getpass.getpass("API credential (hidden): ")
    os.environ["OPENAI_API_KEY"] = secret
    del secret
    try:
        code = paired_augmentation.run(root, root / "reports/live-attempt-02/paired-run", output)
        score = direct_ab.score(argparse.Namespace(gold=str(root / "examples/gold.synthetic.json"),
            run=str(output), accuracy=str(root.parent / "repo-comparison/accuracy")))
        return max(code, score)
    finally:
        os.environ.pop("OPENAI_API_KEY", None)


if __name__ == "__main__":
    try: raise SystemExit(main())
    except Exception as exc:
        print(json.dumps({"status": "stopped", "error_type": type(exc).__name__}), flush=True)
        raise SystemExit(1)

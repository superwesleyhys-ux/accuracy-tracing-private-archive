"""Contract tests. Every inference response here is an explicit fake."""
import asyncio
from copy import deepcopy
from dataclasses import asdict
import io
import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import direct_ab as ab
import paired_augmentation as paired
PROJECTS = Path(os.environ.get("DIRECT_AB_PROJECTS_ROOT", str(ROOT.parent / "repo-comparison")))
Agent, p = ab.load_projects(PROJECTS / "original", PROJECTS / "accuracy")
from agent import prompts
from rich.console import Console


def inputs():
    return json.loads((ROOT / "examples/inputs.synthetic.json").read_text())


def response(value, completion_tokens=5):
    return NS(id="fake-response", model="fake-model", usage=NS(prompt_tokens=10, completion_tokens=completion_tokens),
              choices=[NS(finish_reason="stop", message=NS(content=json.dumps(value), refusal=None))])


def final(value="unverifiable"):
    return {"decision": value, "probabilities": {x: float(x == value) for x in ab.LABELS},
            "source": {"status": "unresolved", "roots": [], "edges": []}, "evidence": []}


class Tests(unittest.TestCase):
    def test_gold_fields_rejected_in_inputs(self):
        data = inputs(); data["cases"][0]["truth"] = "false"
        with self.assertRaises(ValueError): ab.clean_inputs(data)

    def test_material_gold_metadata_rejected(self):
        data = inputs(); data["cases"][0]["materials"][0]["gold_stance"] = "supports"
        with self.assertRaises(ValueError): ab.clean_inputs(data)

    def test_dataclass_schema_decode_and_boolean_types(self):
        spec = ab.schema(p.Analysis)
        self.assertFalse(spec["additionalProperties"])
        self.assertEqual(set(spec["properties"]), set(spec["required"]))
        self.assertEqual(p.Analysis(), ab.decode(p.Analysis, json.loads(json.dumps(asdict(p.Analysis())))))
        with self.assertRaises(ValueError): ab.decode(bool, "false")

    def test_call_budget_stops_before_another_request(self):
        transport = lambda **kw: response({})
        client = ab.BudgetClient("fake", ab.Budget(calls=1), transport=transport)
        client.call("s", "u", json_mode=True)
        with self.assertRaises(RuntimeError): client.call("s", "u", json_mode=True)
        self.assertEqual(1, client.calls)

    def test_relation_schema_prevents_observed_live_enum_failure(self):
        props = ab.schema(p.Analysis)["properties"]["relations"]["items"]["properties"]
        self.assertIn("cites", props["kind"]["enum"])
        self.assertNotIn("direct_citation", props["kind"]["enum"])
        self.assertNotIn("evidenced", props["status"]["enum"])
        verifier_gap = ab.schema(p.VerificationResult)["properties"]["gaps"]["items"]
        self.assertEqual(["verification"], verifier_gap["properties"]["stage"]["enum"])

    def test_unique_quote_alignment_preserves_verbatim_text(self):
        span = {"version_id": "v", "quote": "notice", "start": 0, "end": 6}
        output = ab.align_spans({"basis": [span]}, [{"version_id": "v", "content": "A notice exists."}])
        self.assertEqual({**span, "start": 2, "end": 8}, output["basis"][0])
        self.assertEqual(0, span["start"])

    def test_ambiguous_or_missing_quotes_cannot_be_repaired(self):
        for quote in ["notice", "invented"]:
            span = {"version_id": "v", "quote": quote, "start": 0, "end": 1}
            with self.assertRaises(ValueError):
                ab.align_spans(span, [{"version_id": "v", "content": "A notice; another notice."}])

    def test_arbitrary_remote_error_text_is_not_propagated(self):
        def transport(**kw): raise ValueError("PRIVATE_SENTINEL")
        client = ab.BudgetClient("fake", ab.Budget(), transport=transport)
        with self.assertRaises(RuntimeError) as caught: client.call("s", "u")
        self.assertNotIn("PRIVATE_SENTINEL", str(caught.exception))
        self.assertNotIn("PRIVATE_SENTINEL", json.dumps(client.records))

    def test_output_budget_and_actual_usage(self):
        calls = []
        def transport(**kw): calls.append(kw); return response({}, 5)
        client = ab.BudgetClient("fake", ab.Budget(output_tokens=5), transport=transport)
        client.call("s", "u", json_mode=True)
        with self.assertRaises(RuntimeError): client.call("s", "u", json_mode=True)
        self.assertEqual(5, calls[0]["max_completion_tokens"])
        self.assertEqual(10, client.usage()["input_tokens"])

    def test_shared_prefix_consumes_budget_without_resending_requests(self):
        calls = []
        def transport(**kw): calls.append(kw); return response({})
        client = ab.BudgetClient("fake-model", ab.Budget(calls=2), transport=transport)
        cache = [{"sequence": 1, "system": "original analysis", "actual_model": "fake-model",
                  "usage": {"input_tokens": 10, "output_tokens": 5}, "seconds": 2},
                 {"sequence": 2, "system": "final assessment", "seconds": 1}]
        reused = paired.seed_prefix(client, cache, {"seconds": 3})
        self.assertEqual(2, reused["seconds"])
        self.assertEqual(1, client.calls)
        self.assertEqual([], calls)
        client.call("new", "u", json_mode=True)
        with self.assertRaises(RuntimeError): client.call("extra", "u")
        self.assertEqual(1, len(calls))
        self.assertEqual(20, client.used_input)
        self.assertNotIn("reused_common_prefix", cache[0])

    def test_shared_prefix_rejects_different_model(self):
        client = ab.BudgetClient("new-model", ab.Budget(), transport=lambda **kw: response({}))
        records = [{"sequence": 1, "actual_model": "other-model"},
                   {"sequence": 2, "system": "final assessment"}]
        with self.assertRaises(ValueError): paired.seed_prefix(client, records, {"seconds": 1})

    def test_missing_usage_is_an_error(self):
        def transport(**kw):
            r = response({});r.usage = None;return r
        client = ab.BudgetClient("fake", ab.Budget(), transport=transport)
        with self.assertRaises(RuntimeError): client.call("s", "u", json_mode=True)
        self.assertEqual("RuntimeError", client.records[0]["error_type"])

    def test_both_arms_share_future_filter(self):
        case = inputs()["cases"][0]
        case["materials"][0]["available_at"] = "2026-09-05T00:00:00Z"
        cleaned, excluded = ab.eligible_case(p, case)
        self.assertEqual(1, len(cleaned["materials"]))
        self.assertEqual(1, len(excluded))
        self.assertEqual(2, len(case["materials"]))

    def test_formatter_cannot_upgrade_accuracy(self):
        client = ab.BudgetClient("fake", ab.Budget(), transport=lambda **kw: response(final("true")))
        with self.assertRaisesRegex(ValueError, "override"):
            ab.final_prediction(client, inputs()["cases"][0], {},
                                {"fact_status": "unresolved", "provenance_status": "partial"})

    def test_formatter_unknown_evidence_is_error(self):
        output = final();output["evidence"] = [{"id": "invented", "stance": "supports", "origin": "x"}]
        client = ab.BudgetClient("fake", ab.Budget(), transport=lambda **kw: response(output))
        with self.assertRaisesRegex(ValueError, "Unknown evidence"):
            ab.final_prediction(client, inputs()["cases"][0], {})

    def test_actual_original_pipeline_and_accuracy_engine_with_fake_transport(self):
        case = inputs()["cases"][0]
        script = {
            prompts.DECONSTRUCT_PROMPT: {"core_event": "Fixture", "entities": {}, "key_claims": []},
            prompts.SEARCH_PLAN_PROMPT: {"queries": [{"angle": "a", "query": "fixture"}]},
            prompts.SOURCE_TRACE_PROMPT: {"sources": []},
            prompts.SOURCE_VERIFY_PROMPT: {"consistent_facts": [], "disputed_facts": []},
            prompts.GROUNDING_CHECK_PROMPT: {"checks": []},
            prompts.TIMELINE_BUILD_PROMPT: {"events": []},
            prompts.SYNTHESIS_PROMPT: {},
        }
        def transport(**kw):
            system = kw["messages"][0]["content"]
            if system.startswith(ab.CORPUS_RULE + "Decompose"):
                return response(asdict(p.Analysis()))
            if system.startswith(ab.CORPUS_RULE + "Verify target"):
                return response(asdict(p.VerificationResult()))
            if "final assessment" in system: return response(final())
            for prompt, value in script.items():
                if system == ab.CORPUS_RULE + prompt: return response(value)
            return response("Fixture text")
        client = ab.BudgetClient("fake", ab.Budget(), transport=transport)
        report = asdict(asyncio.run(Agent(ab.OriginalCorpusClient(client, case), max_depth=0,
            console=Console(file=io.StringIO(), quiet=True)).run(case["target"]["text"])))
        baseline_calls = client.calls
        trace = ab.run_accuracy(p, client, case, report)
        output = ab.final_prediction(client, case, report, trace)
        self.assertEqual(8, baseline_calls)
        self.assertGreater(trace["usage"]["decomposition_calls"], len(case["materials"]))
        self.assertEqual([], trace["errors"])
        self.assertEqual("unverifiable", output["decision"])
        self.assertTrue(all(r["actual_model"] == "fake-model" for r in client.records))

    def test_preflight_missing_auth_never_generates_predictions(self):
        with tempfile.TemporaryDirectory() as temp, patch.dict(os.environ, {}, clear=True):
            args = NS(inputs=str(ROOT / "examples/inputs.synthetic.json"), output=str(Path(temp) / "run"),
                      model="explicit-test-model", reasoning_effort=None, depth=0, seed=0,
                      original=str(PROJECTS / "original"), accuracy=str(PROJECTS / "accuracy"))
            self.assertEqual(2, ab.run(args))
            status = json.loads((Path(args.output) / "status.json").read_text())
            self.assertEqual(0, status["model_calls"])
            self.assertIsNone(status["scores"])
            self.assertFalse((Path(args.output) / "results.json").exists())

    def test_failed_arm_is_not_silently_excluded(self):
        gold = json.loads((ROOT / "examples/gold.synthetic.json").read_text())
        with tempfile.TemporaryDirectory() as temp:
            rows = [{"id": c["id"], "arm": a, "status": "error", "prediction": None}
                    for c in gold["cases"] for a in ["original", "accuracy"]]
            ab.write(Path(temp) / "results.json", rows)
            args = NS(gold=str(ROOT / "examples/gold.synthetic.json"), run=temp, accuracy=str(PROJECTS / "accuracy"))
            self.assertEqual(1, ab.score(args))
            self.assertIsNone(json.loads((Path(temp) / "scores.json").read_text())["scores"])


if __name__ == "__main__": unittest.main()

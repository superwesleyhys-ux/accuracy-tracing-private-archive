"""Offline replay of saved semantic outputs to locate the observed regression.

No model calls. The in-memory gate ablation is a diagnostic intervention, not a
production patch or a new accuracy result. Original sources/logs remain intact.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import socket
import sys
import types
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import direct_ab as ab


def replay(engine, case, saved, rounds):
    history = iter(deepcopy(saved["analysis_history"]))
    checks = iter(deepcopy(saved["verification_history"]))

    class Provider:
        def search(self, target, tasks, round_number, limit):
            return iter([engine.MaterialVersion(**m) for m in case["materials"]][:limit])

    class Decomposer:
        def decompose(self, target, material, context):
            entry = next(history)
            assert entry["version_id"] == material.version_id
            assert entry["round"] == context["usage"]["rounds"]
            return ab.decode(engine.Analysis, entry["analysis"])

    class Verifier:
        def verify(self, target, context):
            entry = next(checks)
            assert entry.pop("round") == context["usage"]["rounds"]
            return ab.decode(engine.VerificationResult, entry)

    config = {**saved["config"], "max_rounds": rounds}
    report = engine.run_provenance(engine.Target(**case["target"]), Provider(), Decomposer(),
                                  Verifier(), engine.TraceConfig(**config))
    # Match the original persistence boundary: dataclass tuples become JSON arrays.
    return json.loads(json.dumps(report))


def gate_ablation(engine):
    original = Path(engine.__file__).read_text()
    gate = 'fact_status = "unresolved" if any(item.stage == "verification" for item in gaps.values()) else check.verdict'
    assert original.count(gate) == 1
    changed = original.replace(gate, 'fact_status = check.verdict  # DIAGNOSTIC ABLATION ONLY')
    module = types.ModuleType("_diagnostic_gate_ablation")
    module.__file__ = engine.__file__
    sys.modules[module.__name__] = module
    exec(compile(changed, "<in-memory diagnostic gate ablation>", "exec"), module.__dict__)
    return module


def concise(report):
    return {"verifier_verdicts": [r["verdict"] for r in report["verification_history"]],
            "engine_verdicts": [o["verdict"] for o in report["operations"] if o["action"] == "verification_completed"],
            "final_fact_status": report["fact_status"], "provenance_status": report["provenance_status"],
            "usage": report["usage"], "stop_reason": report["stop_reason"], "errors": report["errors"]}


def main():
    projects = ROOT.parent / "repo-comparison"
    _, engine = ab.load_projects(projects / "original", projects / "accuracy")
    counterfactual = gate_ablation(engine)
    run = ROOT / "reports/live-attempt-03-shared-prefix"
    baseline_rows = json.loads((run / "results.json").read_text())
    rows, network_attempts = [], []

    def no_network(*args, **kwargs):
        network_attempts.append(True)
        raise RuntimeError("Network prohibited in diagnostic replay")

    with patch.object(socket.socket, "connect", no_network), patch.object(socket, "create_connection", no_network):
        for index in range(2):
            case = json.loads((run / f"case-{index}-shared-input.json").read_text())["case"]
            saved = json.loads((run / f"case-{index}-accuracy-report.json").read_text())["accuracy_trace"]
            two = replay(engine, case, saved, 2)
            assert two == saved, "Unmodified replay must exactly reproduce the saved trace"
            one = replay(engine, case, saved, 1)
            assert one["verification_history"] == saved["verification_history"][:1]
            assert one["fact_status"] == two["fact_status"]
            without_gate = replay(counterfactual, case, saved, 2)
            assert without_gate["verification_history"] == saved["verification_history"]
            assert not without_gate["errors"]
            expected = "conflicting" if index == 0 else "unresolved"
            assert without_gate["fact_status"] == expected
            calls = json.loads((run / f"case-{index}-accuracy-calls.json").read_text())
            second_round = []
            for call in calls:
                if call.get("reused_common_prefix"): continue
                payload = json.loads(call["user"])
                context = payload.get("context")
                if context and context["usage"]["rounds"] == 2: second_round.append(call)
            row = {"id": case["target"]["id"],
                   "original_decision": next(r["prediction"]["decision"] for r in baseline_rows
                                             if r["arm"] == "original" and r["id"] == case["target"]["id"]),
                   "one_round_replay": concise(one), "two_round_replay": concise(two),
                   "gate_ablation_not_production_fix": concise(without_gate),
                   "new_versions_per_round": [o["new_eligible_versions"] for o in two["operations"] if o["action"] == "progress_checked"],
                   "self_revisit_cycles": [o for o in two["operations"] if o["action"] == "revisit_cycle_detected"],
                   "second_round_recorded_usage": {"calls": len(second_round),
                       **{k: sum(c["usage"][k] for c in second_round) for k in ["input_tokens", "output_tokens"]}},
                   "full_two_round_trace_reproduced_exactly": True}
            rows.append(row)

    result = {"method": "Six deterministic engine replays using saved model analyses/verdicts",
              "new_model_calls": 0, "network_attempts": len(network_attempts),
              "production_sources_modified": False, "gold_modified": False,
              "engine_sha256": hashlib.sha256(Path(engine.__file__).read_bytes()).hexdigest(),
              "live_adapter_sha256": hashlib.sha256((ROOT / "direct_ab.py").read_bytes()).hexdigest(),
              "cases": rows,
              "limits": ["Removing the override recovers conflicting, not false; it does not repair the gold-label miss.",
                         "No fresh one-round model/formatter trial was run; these are saved-output engine replays.",
                         "This establishes code effects and round timing, not causal effects of prompt wording on the model."]}
    destination = ROOT / "diagnostics/regression-diagnosis.json"
    ab.write(destination, result)
    print(json.dumps({"replays": 6, "exact_trace_matches": 2, "network_attempts": len(network_attempts),
                      "new_model_calls": 0, "output": str(destination)}))


if __name__ == "__main__": main()

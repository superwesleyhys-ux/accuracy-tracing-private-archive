"""Interactive credential handoff: memory only, official endpoint, no key logging."""
import argparse
import getpass
import json
import logging
import os
from pathlib import Path
import sys

from openai import OpenAI
import direct_ab


def main():
    if not sys.stdin.isatty():
        raise SystemExit("A terminal with echo disabled is required")
    logging.disable(logging.CRITICAL)
    secret = getpass.getpass("API credential (hidden): ")
    os.environ["OPENAI_API_KEY"] = secret
    del secret
    root = Path(__file__).resolve().parent
    model = "gpt-6-astra"
    number = 1
    while (root / "reports" / f"live-attempt-{number:02d}").exists():
        number += 1
    attempt = root / "reports" / f"live-attempt-{number:02d}"
    attempt.mkdir(parents=True, exist_ok=False)
    try:
        client = OpenAI(api_key=os.environ["OPENAI_API_KEY"], base_url="https://api.openai.com/v1",
                        max_retries=0, timeout=20)
        try:
            model_info = client.models.retrieve(model)
            status = {"status": "model_metadata_accessible", "requested_model": model, "returned_model": model_info.id}
            direct_ab.write(attempt / "access.json", status)
            print(json.dumps(status), flush=True)
        except Exception as exc:
            allowed = {"invalid_api_key", "model_not_found", "insufficient_quota", "rate_limit_exceeded", "permission_denied"}
            code = getattr(exc, "code", None)
            status = {"status": "model_access_failed", "error_type": type(exc).__name__,
                      "http_status": getattr(exc, "status_code", None),
                      "error_code": code if code in allowed else None, "model_inference_calls": 0}
            direct_ab.write(attempt / "access.json", status)
            print(json.dumps(status), flush=True)
            return 2
        args = argparse.Namespace(inputs=str(root / "examples/inputs.synthetic.json"),
            original=str(root.parent / "repo-comparison/original"),
            accuracy=str(root.parent / "repo-comparison/accuracy"), model=model,
            reasoning_effort=None, depth=1, seed=0, output=str(attempt / "paired-run"))
        result = direct_ab.run(args)
        if (Path(args.output) / "results.json").exists():
            result = max(result, direct_ab.score(argparse.Namespace(
                gold=str(root / "examples/gold.synthetic.json"), run=args.output, accuracy=args.accuracy)))
        return result
    finally:
        os.environ.pop("OPENAI_API_KEY", None)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(json.dumps({"status": "stopped", "error_type": type(exc).__name__}), flush=True)
        raise SystemExit(1)

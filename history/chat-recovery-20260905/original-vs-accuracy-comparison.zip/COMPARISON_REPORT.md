# 原新闻项目与 Accuracy Tracing：固定版本实跑对照

2026-09-05 UTC。

**结论：Accuracy 的版本保留和引用准入约束比原新闻项目完整，但本次没有测得模型准确率提升。两个项目各有可复用部分，尚未形成同一模型、同一任务集下可直接比较的完整 agent。**

## 这次确实读取了 GitHub

权限已生效，GitHub 安装状态为 all repositories。本次固定的源代码是：

| 对象 | 仓库与提交 |
|---|---|
| 原新闻项目 | [news-tracking-perdiction @ 7895061](https://github.com/superwesleyhys-ux/news-tracking-perdiction/tree/789506115e7dfef1f2359c2e43bcae4234b8d3f2) |
| Accuracy | [accuracy-tracing @ aca102c](https://github.com/superwesleyhys-ux/accuracy-tracing/tree/aca102cfe13379c5924a5ffa7b60337351e4eaaa) |

原项目取回 11 个文本源文件，排除了提交的 Python 缓存文件。Accuracy 的 49 个仓库文件全部与 GitHub blob SHA-1 校验一致；已有本地文件仅在哈希一致时复用。逐文件 SHA-256 和 Git blob 哈希在 `results/source-manifest.json`。

Accuracy 最新提交的 [GitHub CI 已成功](https://github.com/superwesleyhys-ux/accuracy-tracing/actions/runs/33946570964)，这是已有工作流运行结果。本次没有提交、推送或触发新远端任务。

## 测试方法与适用范围

安装原项目声明的依赖后，直接导入并执行原仓库函数；没有修改两个项目的生产代码。Python 及实际安装的包版本在 `results/environment.json`。

测试用可记录的 `ScriptedLLM` 替换外部模型调用，用手写分解器/验证器输出驱动 Accuracy。运行脚本阻止 socket 连接；新闻网络调用、模型 API 调用均为 0。所有新闻内容为虚构桥梁案例。

这是一组有针对性的故障注入，目的在于检查程序如何处理版本、引用、时间和错误语义。两个项目的输入输出 schema 不同，下表比较对应的程序属性，不能视为相同模型的端到端 A/B 实验。特别是：`is_original` 是原项目保存的标记，Accuracy 的 `provenance_status` 是另一个层级的输出，两者并非同义指标。

没有将这组挑选过的边界案例汇总成“准确率”，也没有把测试覆盖数量用作项目优劣分数。

## 五项对应行为

| 输入或挑战 | 原新闻项目实测 | Accuracy 实测 | 解释 |
|---|---|---|---|
| 同一 URL 的原报道与更正 | 只保留第一个版本，更正内容丢失 | 保留两个版本 | Accuracy 提供了实质性的版本管理能力 |
| 模型声称 source_count=2，但未提供引用 | 时间线出现 `verified=true`，来源列表为空 | `unresolved`，停止原因为 `verifier_error` | Accuracy 拒绝无证据依据的肯定结果 |
| 材料发布/可用时间晚于目标截止时间 | 原合并函数保留；无截止准入接口 | 可用证据列表为空，保存排除原因 | Accuracy 支持证据图的时间准入；不等于完全隔离未来信息 |
| 输入自称 is_original=true，无来源路径 | 原样存储 `is_original=true` | `partial`，没有 original finding | 原模型判断标记与程序确立的出处需要分别表达 |
| 引文原文完全匹配，但内容反驳目标；注入错误肯定判断 | 接受并标记 verified | 接受并输出 supported | 两者都不能仅靠结构校验纠正语义错误 |

最后一项的目标为“桥已开放”，引用文本为“桥尚未开放”。Accuracy 验证了引用位置和文字确实存在，但接受了插件给出的错误 `supported` 判断。它的模块说明明确将语义判断交给插件；本次实验证实了这一边界。

对应原始输出均在 `results/cases.json`；Accuracy 每个挑战的完整 trace 也单独保存。

## 三项架构专属问题

**原版：字符串 false 会变成匹配成功。** 向比较阶段注入 `{"matched":"false","score":0}`，实际返回 `matched=true`。原因是 `bool("false")` 为真。这会在上游产生类型错误时污染 replay 的成功计数。应严格校验 JSON 布尔类型，对非法类型报错。[代码位置](https://github.com/superwesleyhys-ux/news-tracking-perdiction/blob/789506115e7dfef1f2359c2e43bcae4234b8d3f2/agent/core.py#L444)

**Accuracy：片段父节点可以悬空。** 目标 ID 为 `bridge-claim`，分解器返回 `parent_id="different-target"`，且该 ID 不属于任何已知节点。实际输出保留了该片段，错误列表为空。当前只检查父 ID 非空，没有验证它能连接到当前目标。应校验父节点存在、所属目标和循环依赖。[代码位置](https://github.com/superwesleyhys-ux/accuracy-tracing/blob/aca102cfe13379c5924a5ffa7b60337351e4eaaa/newsverify/provenance.py#L252)

**Accuracy：未来材料仍进入语义分解器。** 实际结果中证据图准入列表为空，但分解器记录了 `future` 版本。若分解器有状态，可能把后来信息带回历史判断。当前 README 已披露这一限制。严格历史评估需要在隔离的语义上下文中处理材料，且不能把未来上下文传给历史预测器；只在图层过滤不足以解决。[调用位置](https://github.com/superwesleyhys-ux/accuracy-tracing/blob/aca102cfe13379c5924a5ffa7b60337351e4eaaa/newsverify/provenance.py#L494)

这些不是三个对应的 A/B 指标，不能与前表相加计算两个项目的准确率。本次保留固定提交，没有顺手修补生产代码后重新给同一版本算分。

## 运行覆盖

| 项目 | 本次实际结果 |
|---|---|
| 原版依赖和 Python 模块 | 安装、导入成功 |
| 原版 FastAPI 模块 | 导入成功，trace/replay/health 路由存在；未启动对外服务 |
| 原版主 `run` 流程 | 在因果深度为 0、单条检索结果的脚本输入下完成；8 次模拟接口调用；不是完整因果搜索能力测试 |
| 原版返回验证缺口 | 脚本流程结束时仍有缺口，搜索与解构各调用 1 次；没有因为该缺口重开搜索 |
| Accuracy 回环演示 | 完成，3 轮检索、4 版本、6 次分解、3 次验证；使用其已有独立演示数据 |
| Accuracy 固定提交的回归测试 | 76 项，失败 0、错误 0、跳过 0 |
| 新的边界检查 | 5 项对应属性 + 3 项架构专属检查；逐条记录结果，没有总准确率 |

两条脚本演示的数据与任务不同，不能用它们的调用次数或延迟宣称某一版效率更高。76 项回归测试全部通过，也不意味着这里新增发现的缺口不存在。

## 原代码哪些值得用

| 能力 | 原版价值 | 与 Accuracy 的关系 |
|---|---|---|
| 模型调用封装和 token 累计 | 已有 `LLMClient`，存在实际外部 API 调用路径 | 可作为接入起点，需加类型、超时、预算及每次调用记录 |
| 搜索规划与双轨编排 | 已有搜索角度、因果分析、聚合流程 | 可以复用规划逻辑；搜索摘要需转换为可重新打开的真实材料版本 |
| 事件时间线与报告模型 | 已有 `EventNode`、`TimelineEvent`、报告结构 | 可复用展示结构；verified 应由证据条件产生 |
| 历史 replay | 已有遮蔽步骤、预测、比较入口 | “真值”由同一流程构造，不能直接用它的 accuracy 作为独立准确率；需要外部审定的测试标签 |
| 版本和引用管理 | 原版主要依赖 URL、摘要和模型标记 | Accuracy 的不可变材料、引用位置和缺口队列适合补入 |
| 独立评分 | 原版没有对应固定目标评估接口 | Accuracy 的 gold/prediction schema 与比较工具可以复用 |

原 README 提及的 `web/frontend`、`web/backend` 与 `.env.example` 在本次仓库树中不存在，实际后端在 `backend/`。这属于交付/文档缺口，不能当作新闻模型能力结论。

## 与 ChatGPT、Terminal-Bench 的比较状态

用户要求的“基础模型/原 agent vs 加入 Accuracy 回环”还没有真实成绩。当前 `OPENAI_API_KEY` 未配置；Accuracy 也没有通用语义适配器或终端任务执行 agent。GitHub 的读写权限已经解决，但不提供模型调用认证。

因此本报告的 `chatgpt_vs_accuracy.score` 和 `terminal_bench.score` 均为 null。上一次的 22/22 合成策略样例、NVScore 手算演示、这次的 76/76 回归测试，都不能填入这两个成绩。

下一次有效对照应先固定同一模型、输入新闻/任务、可用资料、总 token 和工具预算；将原版检索接入 Accuracy 的证据版本和语义接口；由与两个运行都分离的审定数据评分。终端任务另需 Harbor agent 接口和可运行的任务环境。[Harbor agent 接口](https://www.harborframework.com/docs/agents)

## 复现

附件包含本测试脚本、源文件哈希和原始结果，不重新打包两个已有 GitHub 仓库。将两个仓库以如下目录检出，安装原项目依赖后运行脚本：

```bash
git clone https://github.com/superwesleyhys-ux/news-tracking-perdiction.git original
git -C original checkout 789506115e7dfef1f2359c2e43bcae4234b8d3f2
git clone https://github.com/superwesleyhys-ux/accuracy-tracing.git accuracy
git -C accuracy checkout aca102cfe13379c5924a5ffa7b60337351e4eaaa
python3 -m venv venv
venv/bin/python -m pip install -r original/requirements.txt
venv/bin/python run_controlled_comparison.py
```

依赖在原仓库中没有锁定，上述安装可能得到不同包版本；本次确切版本已另存。脚本仅执行受控输入，不会发送真实新闻请求或修改远端仓库。

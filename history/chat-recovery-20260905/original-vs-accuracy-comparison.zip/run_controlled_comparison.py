"""Execute pinned original and Accuracy code with deterministic injected outputs.

No model or news calls. This measures program behavior, NOT model accuracy.
Production source is never patched. Read results/cases.json for every observation.
"""
from __future__ import annotations

import asyncio
from collections import Counter
from copy import deepcopy
from dataclasses import asdict, replace
from datetime import datetime, timezone
import io
import json
from pathlib import Path
import socket
import sys
import unittest

ROOT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT / "original"), str(ROOT / "accuracy")]
from rich.console import Console
from agent.core import NewsTracingAgent
from agent import prompts
from agent.models import EventNode, FocusSubject, RelativeStep, StepPrediction
from newsverify.provenance import (
    Analysis, Fragment, MaterialVersion, ReplayTraceProvider, Span, Target,
    VerificationResult, run_provenance,
)
from newsverify.trace_demo import run_demo


def forbid_network(*args, **kwargs):
    raise RuntimeError("Network disabled in controlled comparison")


socket.socket.connect = forbid_network
socket.create_connection = forbid_network
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)
TARGET = Target("bridge-claim", "The bridge has opened.", "2026-09-04T20:00:00Z")
EARLY = "2026-09-04T12:00:00Z"
QUIET = Console(file=io.StringIO(), quiet=True)


class ScriptedLLM:
    token_summary = "Controlled injection: zero model calls and zero model tokens"

    def __init__(self, responses):
        self.responses = responses
        self.calls = []

    async def query_json(self, system, user, **kwargs):
        self.calls.append({"prompt": next((n for n in dir(prompts) if getattr(prompts, n) == system), "unknown"),
                           "web_search_requested": kwargs.get("web_search", False)})
        value = self.responses[system]
        return deepcopy(value(user) if callable(value) else value)

    async def query(self, system, user, **kwargs):
        self.calls.append({"prompt": "DIRECT_RESPONSE_PROMPT", "web_search_requested": False})
        return "Controlled fixture response; no model inference."


def source(content="The bridge has opened.", version="v1", date=EARLY):
    return {"url": "https://example.org/bridge", "outlet": "Fixture news",
            "publish_time": date, "available_at": date,
            "availability_basis": "Synthetic exact-version observation",
            "version_id": version, "content": content,
            "facts": [{"claim": content}], "source_type": "fixture", "is_original": False}


def material(raw):
    return MaterialVersion(raw["version_id"], raw["url"], raw["content"],
                           "2026-09-06T00:00:00Z", raw["publish_time"],
                           raw["available_at"], raw["availability_basis"], raw["outlet"])


class FnDecomposer:
    def __init__(self, fn): self.fn = fn
    def decompose(self, target, item, context): return self.fn(target, item, context)


class FnVerifier:
    def __init__(self, fn): self.fn = fn
    def verify(self, target, context): return self.fn(target, context)


def trace(records, **kwargs):
    return run_provenance(TARGET, ReplayTraceProvider((tuple(material(x) for x in records),)), **kwargs)


async def main():
    cases = []
    traces = {}

    # The controls below specify expected properties before calling production code.
    first = source()
    correction = source("Correction: the bridge opens next month.", "v2")
    old = NewsTracingAgent._merge_sources([[first], [correction]])
    new = trace([first, correction]); traces["revisions"] = new
    cases.append({"id": "same_url_revision", "expected": "Preserve both distinct text versions",
                  "scope": "paired structural check",
                  "original": {"preserved_versions": len(old), "facts": [f.claim for s in old for f in s.key_facts]},
                  "accuracy": {"preserved_versions": len(new["materials"])},
                  "original_meets_property": len(old) == 2,
                  "accuracy_meets_property": len(new["materials"]) == 2})

    llm = ScriptedLLM({prompts.TIMELINE_BUILD_PROMPT: {"events": [{"title": TARGET.text,
                         "date": EARLY, "source_count": 2, "sources": []}]}})
    old_events = await NewsTracingAgent(llm, console=QUIET)._build_timeline([], EventNode("Bridge", EARLY, ""))
    new = trace([first], verifier=FnVerifier(lambda t, c: VerificationResult("supported", (), "Injected source_count=2 with no citations")))
    traces["no_citations"] = new
    cases.append({"id": "no_citations", "expected": "Do not certify a claim from a source-count assertion alone",
                  "scope": "paired admission check; output schemas differ",
                  "original": {"verified": old_events[0].verified, "sources": old_events[0].sources},
                  "accuracy": {"fact_status": new["fact_status"], "stop_reason": new["stop_reason"]},
                  "original_meets_property": not old_events[0].verified,
                  "accuracy_meets_property": new["fact_status"] == "unresolved"})

    future = source("The bridge opened after the cutoff.", "future", "2026-09-05T12:00:00Z")
    old = NewsTracingAgent._merge_sources([[future]])
    new = trace([future]); traces["future"] = new
    cases.append({"id": "future_admission", "expected": "Exclude future versions from historical evidence",
                  "scope": "paired input check; original has no as_of admission interface",
                  "original": {"pool_size": len(old), "cutoff_enforced": False},
                  "accuracy": {"eligible": new["eligible_version_ids"], "reasons": new["observations"][0]["reasons"]},
                  "original_meets_property": False,
                  "accuracy_meets_property": not new["eligible_version_ids"]})

    claimed = source(); claimed["is_original"] = True
    old = NewsTracingAgent._merge_sources([[claimed]])
    new = trace([claimed]); traces["self_declared_origin"] = new
    cases.append({"id": "self_declared_origin", "expected": "Keep a source-origin assertion separate from established lineage",
                  "scope": "paired representation check; original stores a flag, Accuracy reports a provenance state",
                  "original": {"is_original": old[0].is_original},
                  "accuracy": {"provenance_status": new["provenance_status"], "origins": new["origins"]},
                  "original_meets_property": not old[0].is_original,
                  "accuracy_meets_property": new["provenance_status"] != "original_material_located"})

    # A syntactically valid source span cannot validate semantics by itself.
    contrary = source("The bridge has not opened.")
    llm = ScriptedLLM({prompts.TIMELINE_BUILD_PROMPT: {"events": [{"title": TARGET.text,
        "date": EARLY, "source_count": 2, "sources": [{"url": contrary["url"], "title": contrary["content"]}]}]}})
    old_events = await NewsTracingAgent(llm, console=QUIET)._build_timeline(
        NewsTracingAgent._merge_sources([[contrary]]), EventNode("Bridge", EARLY, ""))
    raw = material(contrary)
    new = trace([contrary], verifier=FnVerifier(lambda t, c: VerificationResult(
        "supported", (Span(raw.version_id, 0, len(raw.content), raw.content),),
        "Deliberately wrong semantic verdict attached to an exact, contrary quote")))
    traces["semantic_error"] = new
    cases.append({"id": "wrong_semantics_valid_span", "expected": "Contrary text must not support the target",
                  "scope": "paired injected semantic error; structural validation cannot repair this",
                  "original": {"verified": old_events[0].verified},
                  "accuracy": {"fact_status": new["fact_status"]},
                  "original_meets_property": not old_events[0].verified,
                  "accuracy_meets_property": new["fact_status"] != "supported"})

    # Checks specific to each architecture are not counted as paired scores.
    seen = []
    def inspect_future(t, item, context):
        seen.append(item.version_id)
        return Analysis()
    new = trace([future], decomposer=FnDecomposer(inspect_future))
    cases.append({"id": "future_decomposer_exposure", "scope": "accuracy-only limitation",
                  "expected": "A strict historical semantic process must not see future content",
                  "accuracy": {"decomposer_saw": seen, "eligible": new["eligible_version_ids"]},
                  "accuracy_meets_property": not seen})

    def wrong_parent(t, item, context):
        return Analysis(fragments=(Fragment("f", item.content,
            Span(item.version_id, 0, len(item.content), item.content), "different-target"),))
    new = trace([first], decomposer=FnDecomposer(wrong_parent)); traces["wrong_parent"] = new
    cases.append({"id": "fragment_parent_identity", "scope": "accuracy-only validation gap",
                  "expected": "Reject or resolve a fragment parent that belongs to no known target/fragment",
                  "accuracy": {"target_id": TARGET.id, "parents": [x["parent_id"] for x in new["fragments"]],
                               "errors": new["errors"]},
                  "accuracy_meets_property": bool(new["errors"]) or not new["fragments"]})

    llm = ScriptedLLM({prompts.STEP_COMPARE_PROMPT: {"matched": "false", "score": 0, "note": "Injected malformed boolean"}})
    agent = NewsTracingAgent(llm, console=QUIET)
    result = await agent._compare_step(StepPrediction(0, "Wrong", "", "", "", 0),
        RelativeStep(0, EARLY, "Correct", "", ""))
    cases.append({"id": "string_false", "scope": "original-only validation bug",
                  "expected": "Reject a string boolean or parse false as false",
                  "original": result, "original_meets_property": result["matched"] is False})

    # Smoke the complete original trace orchestration using the injectable LLM interface.
    llm = ScriptedLLM({
        prompts.DECONSTRUCT_PROMPT: {"core_event": "Bridge opening", "date": EARLY, "entities": {}, "key_claims": [TARGET.text]},
        prompts.SEARCH_PLAN_PROMPT: {"queries": [{"angle": "announcement", "query": "bridge announcement"}]},
        prompts.SOURCE_TRACE_PROMPT: {"sources": [first]},
        prompts.SOURCE_VERIFY_PROMPT: {"consistent_facts": [], "disputed_facts": [], "information_gaps": ["Find original minutes"]},
        prompts.GROUNDING_CHECK_PROMPT: {"checks": []},
        prompts.TIMELINE_BUILD_PROMPT: {"events": []},
        prompts.SYNTHESIS_PROMPT: {"information_gaps": ["Find original minutes"], "key_findings": []},
    })
    original_report = await NewsTracingAgent(llm, max_depth=0, console=QUIET).run(TARGET.text)
    (OUT / "original-trace-scripted.json").write_text(json.dumps(asdict(original_report), indent=2) + "\n")
    (OUT / "original-scripted-calls.json").write_text(json.dumps(llm.calls, indent=2) + "\n")
    accuracy_demo = run_demo()
    (OUT / "accuracy-trace-scripted.json").write_text(json.dumps(accuracy_demo, indent=2) + "\n")
    for name, payload in traces.items():
        (OUT / (name + ".json")).write_text(json.dumps(payload, indent=2) + "\n")

    transcript = io.StringIO()
    suite = unittest.defaultTestLoader.discover(str(ROOT / "accuracy/tests"))
    tests = unittest.TextTestRunner(stream=transcript, verbosity=2).run(suite)
    (OUT / "accuracy-unit-tests.txt").write_text(transcript.getvalue())
    summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source_commits": {"original": "789506115e7dfef1f2359c2e43bcae4234b8d3f2", "accuracy": "aca102cfe13379c5924a5ffa7b60337351e4eaaa"},
        "network_calls": 0, "model_api_calls": 0, "model_id": None,
        "measurement": "deterministic injected-output structural comparison; not real news accuracy",
        "paired_check_count": sum(x["scope"].startswith("paired") for x in cases),
        "architecture_specific_check_count": sum(not x["scope"].startswith("paired") for x in cases),
        "aggregate_accuracy_score": None,
        "original_full_trace": {"status": "completed_with_scripted_LLM", "max_depth": 0,
                                "calls_by_prompt": dict(Counter(x["prompt"] for x in llm.calls)),
                                "source_count": len(original_report.sources), "information_gaps": original_report.information_gaps},
        "accuracy_demo": {"status": "completed_with_scripted_decomposer", "usage": accuracy_demo["usage"]},
        "accuracy_unit_tests": {"run": tests.testsRun, "failures": len(tests.failures), "errors": len(tests.errors), "skipped": len(tests.skipped)},
        "terminal_bench": {"status": "not_run", "score": None},
        "chatgpt_vs_accuracy": {"status": "not_run_no_model_auth_or_terminal_adapter", "score": None},
        "limitations": ["Five paired program properties use semantic-role mappings between different schemas, not an equal-model end-to-end ablation.",
                       "LLM and decomposer outputs are explicit adversarial fixtures.",
                       "Architecture-specific checks are not paired comparisons.",
                       "No significance or percentage accuracy improvement is inferred from selected regression cases.",
                       "No production source was modified; observed weaknesses remain in the pinned commits."],
    }
    (OUT / "cases.json").write_text(json.dumps(cases, ensure_ascii=False, indent=2) + "\n")
    (OUT / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"summary": summary, "cases": cases}, ensure_ascii=False, indent=2))
    return 0 if tests.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))

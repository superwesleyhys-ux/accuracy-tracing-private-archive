# Accuracy Tracing：实跑结果与 Terminal-Bench 接入检查

检查时间：2026-09-05 UTC。结论：现有本地 v0.2.0 的回归测试通过；没有得到 Terminal-Bench、ChatGPT 对比或真实新闻准确率成绩。

## 实际检查的代码

用户提供的仓库为 `https://github.com/superwesleyhys-ux/accuracy-tracing.git`。本次 GitHub 连接读取仓库返回 `404 NOT_FOUND`，按拥有者与仓库名称搜索也没有结果。404 不能区分仓库不存在、名称变化和连接缺少权限。

实际执行的是当前工作区已存在的 `accuracy-tracing` v0.2.0，不能确认它与 GitHub 最新版本一致。未获得远端 commit SHA，未修改或发布远端代码。

本次 Python 源码、测试和 JSON 输入的逐文件 SHA-256 见 `source-manifest.json`；其规范化 JSON 摘要为 `4393737002dabe97ac429b1fa87f7518a36ee55ccf462a5e574b0a530e0a472c`。

## 本次实跑

| 项目 | 结果 | 能说明什么 |
|---|---:|---|
| 单元及回归测试 | 76/76 通过；失败、错误、跳过均为 0 | 已覆盖的实现规则满足测试预期 |
| 旧版合成新闻策略样例 | 22/22 匹配预期 | 带预设证据标注的规则回放成功 |
| 双回环演示 | 3 轮检索，4 个材料版本，6 次分解，3 次验证 | 演示数据能够触发重新分解及验证反馈 |
| 七项指标评分器 | 命令成功 | 能处理给定的手写预测并计算指标 |
| 配对比较工具 | 命令成功；相同输入得到差值 0 | 比较程序运行成功 |
| Terminal-Bench | 未运行；尝试任务数 0；分数 null | 没有可报告的 benchmark 成绩 |
| ChatGPT/模型对比 | 未运行；模型 API 调用数 0 | 没有模型间或回环增益成绩 |
| 真实新闻准确率 | 未测 | 尚未建立可据此判断准确率的数据 |

演示结束状态为 `original_material_located / contradicted / complete`。这些语义结论来自手写适配器。

旧版的单轮基线获得的证据更少，因此不能用这组回放证明相同预算下 looping 更准确。76 项测试中已经包含相关策略测试，不能将 76 与 22 相加宣称 98 个独立验证样本。

## 手写输入的算术输出

以下数值仅属于四条故意含错的手写预测，不是 Accuracy Tracing 或任何模型的性能分数。

| 指标 | 数值 |
|---|---:|
| VP | 0.500000 |
| FR | 0.500000 |
| TR | 0.500000 |
| SR | 0.666667 |
| EN | 0.666667 |
| CA | 0.656250 |
| HFAR | 0.500000 |
| NVScore-v0.2-experimental | 14.002371/100 |

NVScore 的权重仍是实验约定。它不属于 Terminal-Bench，不能换算为 Terminal-Bench 分数。比较样例两组都是同一份手写预测，差值 0 也不是“回环没有效果”的实验结论。

## 代码可复用性判断

| 部分 | 判断 | 依据与限制 |
|---|---|---|
| `newsverify/provenance.py` | 保留并接入真实适配器 | 已提供版本、引用位置、缺口调度、返回后分解及停止记录；语义判定依赖外部适配器 |
| `newsverify/evaluation.py` | 保留 | 固定目标及独立 gold/prediction schema；输入标签质量仍需要外部审定 |
| `newsverify/comparison.py` | 保留 | 提供配对差值及事件聚类抽样；预算和使用量是声明值，尚无独立调用记录核验 |
| `newsverify/trace_demo.py` | 保留为演示和回归用例 | `AnnotatedDemoDecomposer` 是人工预设规则，不能充当通用新闻分析模型 |
| `newsverify/cli.py` 的旧 `benchmark` | 保留为策略回归 | 明确使用合成标注；不能改名为模型准确率报告 |
| Terminal-Bench agent | 需要新增 | 未发现 Harbor 的 agent 接口、终端动作执行循环或真实模型调用 |

判断：这是有用的离线工程骨架，距离能够证明模型能力提升的系统仍缺少真实执行层和独立评估数据。此判断仅针对本次本地版本。

## 为什么 Terminal-Bench 尚未运行

本环境的 PATH 检查发现 Python、uv、git；未发现 Harbor、tb、Docker、Podman、Codex CLI。`OPENAI_API_KEY` 未配置，本次也没有可调用的独立 benchmark 执行工具。

Terminal-Bench 评测的是 agent 在任务环境中完成任务的能力。Harbor 提供 agent 接口和本地或云端任务环境。现有新闻证据回放引擎需要实现相应执行适配，才能作为待评测 agent 参与。仅安装 Harbor 或运行 oracle 都不能得到此项目的模型成绩。[Harbor 运行说明](https://www.harborframework.com/docs/tutorials/running-terminal-bench) · [Agent 接口](https://www.harborframework.com/docs/agents)

当前 Terminal-Bench 官方仓库使用带版本的数据集发布，支持指定 agent 与 model。本次没有下载任务或启动官方评测，因此没有声称采用某个版本完成跑分。[Terminal-Bench 官方仓库](https://github.com/harbor-framework/terminal-bench)

## 解阻后的实验执行顺序

1. 使指定仓库对当前 GitHub 连接可读，固定 commit，并核对与此本地版本的差异。
2. 固定 Terminal-Bench 数据集版本、Harbor 版本、任务集合、模型 ID 和 reasoning 设置；将用户所说的 ChatGPT 对比落实为具体、可记录的模型及 agent 配置。
3. 配置可运行的本地容器或已授权云端任务环境，以及模型调用认证。先运行 oracle 检查环境，单独记录这组结果。
4. 实现终端 agent：接受任务指令，执行终端动作，读取动作输出，每次返回进入分解器，依据缺口决定继续或停止，并保存完整动作轨迹及实际使用量。不能用手写新闻样例替代这一层。
5. 用同一模型和同一组任务比较基础 agent 与加入回环的 agent；固定每题总 token、时间及工具调用预算，记录每个试验的成功、失败和执行错误。
6. 用官方 verifier 计算任务成功率，报告尝试次数、失败数、错误数、预算消耗及配对差值区间。调试子集成绩与完整 benchmark 成绩分别标注。
7. 新闻溯源能力另外使用独立审定、按事件分组的测试集评估。Terminal-Bench 成绩不能直接证明新闻来源识别正确率。

模型行为的评估应保留实际运行轨迹及可复核检查，不能只凭演示印象判断提升。[OpenAI 评估实践](https://developers.openai.com/blog/eval-skills)

## 复现已完成部分

在本地 v0.2.0 项目目录运行：

```bash
python3 -m unittest discover -s tests -v
python3 -m newsverify benchmark examples/benchmark.json
python3 -m newsverify trace-demo
python3 -m newsverify score examples/evaluation_gold.json examples/evaluation_predictions.json
python3 -m newsverify compare examples/evaluation_gold.json examples/comparison_baseline.json examples/comparison_candidate.json --bootstrap-samples 100 --seed 0
```

原始日志及 JSON 均随附件保存。`summary.json` 记录实际执行命令、返回码和本地代码指纹；所有未测项目使用 null，未填为 0 分。

# NewsVerify Harness

An evidence-driven verification loop for news trackers. Collect evidence, check citations and timing, account for shared sources, search again for gaps or disagreement, and produce a bounded, auditable decision.

**Status: an offline, open-source starter prepared for public release.** This is newly written code, not a recovered copy of the author's earlier news tracker. A private tracker can connect through the [adapter contract](docs/ADAPTER_CONTRACT.md).

The starter runs on Python 3.11 or later with the standard library. It includes no live news fetcher, model API calls, credentials, model training, or measured real-world news accuracy.

## Run it

From the repository directory:

```bash
python -m newsverify demo
python -m newsverify verify examples/demo.json --output reports/demo.json
python -m newsverify benchmark examples/benchmark.json --output reports/benchmark.json
python -m unittest discover -s tests -v
```

The bundled examples are synthetic. A passing benchmark means that the implementation matches the fixture's expected policy outcome; it does not establish factual accuracy on live news. The report includes an illustrative single-pass result using the first evidence batch. This is not an equal-budget experiment or proof that the loop improves accuracy.

## What the loop does

1. Start with one claim and an explicit `as_of` cutoff.
2. Ask a provider for evidence with source metadata and a quoted passage.
3. Reject evidence with invalid citation fields, mismatched quotes, or ineligible timestamps.
4. Group related evidence transitively by publisher, origin, canonical URL, or normalized content, so copies do not multiply the source count.
5. Request another search to address missing support or conflicting evidence, within the configured limits.
6. Return the policy outcome together with accepted evidence, rejection reasons, source groups, and the round history.

The default limits are three rounds, 30 examined documents, a 72-hour publication window, and two independent source groups for a one-sided decision. At least two successful search rounds are required before a terminal evidence decision unless `max_rounds=1` is explicitly configured. See the [adapter contract](docs/ADAPTER_CONTRACT.md) for exact inputs and limits.

| Outcome | Meaning |
| --- | --- |
| `supported` | The supplied evidence meets the configured support policy. |
| `contradicted` | The supplied evidence meets the configured contradiction policy. |
| `conflicting` | Eligible evidence contains both supporting and contradicting stances, after the required rounds. |
| `unresolved` | The evidence or remaining budget does not establish a one-sided policy decision. |

These labels describe the evidence admitted under the policy. They are not probabilities of truth. In particular, `supported` does not mean that a claim is guaranteed true.

## Where judgment enters

An adapter or human supplies `stance` as `supports`, `contradicts`, or `neutral`. The starter trusts that annotation. Matching a quote to a supplied document verifies text presence, not whether that text entails the claim or faithfully represents the original publisher. URLs are validated as fields; they are not fetched by the core.

Publisher and origin identifiers are also supplied by the adapter. Grouping reduces obvious duplicate counting but does not independently discover ownership, syndication, source quality, hidden coordination, or provenance. Wrong metadata or stance labels can produce wrong decisions.

No finite search can guarantee that all contradictory reporting was found. Evidence after `as_of` is excluded even if it would clarify the story later. The configurable age window can also exclude relevant older evidence. Re-run a claim with a later cutoff when new reporting arrives; retain the earlier result as an audit record.

## Connect an existing tracker

Implement `provider.search(claim, round_number, intent, limit)` and pass it to `run_verification(claim, provider, config=None)`. Keep ingestion, credentials, private ranking logic, and live operational controls in the adapter. The core needs only normalized claim and evidence records.

Read the [adapter contract](docs/ADAPTER_CONTRACT.md) before wiring a provider. It defines timestamp semantics and the responsibilities that this offline core does not enforce, including network timeouts, provider rate limits, costs, and redaction.

## Project documents

- [Project brief](docs/PROJECT_BRIEF.md): scope, architecture, and integration with the earlier tracker.
- [Roadmap](docs/ROADMAP.md): live adapters and a credible evaluation of the loop.
- [Contributing](CONTRIBUTING.md): focused ways to help.
- [Program application draft](docs/PROGRAM_APPLICATION.md): a truthful, unsubmitted Codex for Open Source application outline.

Released under the [MIT License](LICENSE).
